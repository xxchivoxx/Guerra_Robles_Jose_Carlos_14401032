package com.example.carlos.ejemplo;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}