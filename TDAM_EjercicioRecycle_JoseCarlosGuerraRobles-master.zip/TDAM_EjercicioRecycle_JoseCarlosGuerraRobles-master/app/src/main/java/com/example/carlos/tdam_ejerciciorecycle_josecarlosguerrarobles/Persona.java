package com.example.carlos.tdam_ejerciciorecycle_josecarlosguerrarobles;

/**
 * Created by carlos on 13/02/18.
 */

public class Persona {
    String nombre="";
    String NumControl ="";
    String carrera = "";
    int imagen = 0;


    public Persona(String nombre, String apellido, String carrera, int imagen) {
        this.nombre = nombre;
        this.NumControl = apellido;
        this.carrera = carrera;
        this.imagen = imagen;
    }
}
