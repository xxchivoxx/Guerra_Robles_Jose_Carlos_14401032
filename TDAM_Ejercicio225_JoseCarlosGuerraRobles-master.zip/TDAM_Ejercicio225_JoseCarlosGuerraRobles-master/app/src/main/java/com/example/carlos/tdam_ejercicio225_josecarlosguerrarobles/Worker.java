package com.example.carlos.tdam_ejercicio225_josecarlosguerrarobles;

/**
 * Created by carlos on 11/03/18.
 */

public class Worker {
    int idTrabajador;
    String nombreTrabajador;
    String actividadTrabajador;
    String celularTrabajador;

    public int getIdTrabajador() {
        return idTrabajador;
    }

    public void setIdTrabajador(int idTrabajador) {
        this.idTrabajador = idTrabajador;
    }

    public String getNombreTrabajador() {
        return nombreTrabajador;
    }

    public void setNombreTrabajador(String nombreTrabajador) {
        this.nombreTrabajador = nombreTrabajador;
    }

    public String getActividadTrabajador() {
        return actividadTrabajador;
    }

    public void setActividadTrabajador(String actividadTrabajador) {
        this.actividadTrabajador = actividadTrabajador;
    }

    public String getCelularTrabajador() {
        return celularTrabajador;
    }

    public void setCelularTrabajador(String celularTrabajador) {
        this.celularTrabajador = celularTrabajador;
    }
}
