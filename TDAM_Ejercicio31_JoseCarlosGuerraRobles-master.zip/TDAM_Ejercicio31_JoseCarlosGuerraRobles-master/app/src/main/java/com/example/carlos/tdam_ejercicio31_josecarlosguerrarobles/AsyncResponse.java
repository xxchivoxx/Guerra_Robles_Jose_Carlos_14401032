package com.example.carlos.tdam_ejercicio31_josecarlosguerrarobles;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}