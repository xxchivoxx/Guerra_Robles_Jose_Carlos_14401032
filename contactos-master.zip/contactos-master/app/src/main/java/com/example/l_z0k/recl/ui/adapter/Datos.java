package com.example.l_z0k.recl.ui.adapter;

/**
 * Created by L_Z0K on 21/02/2018.
 */

public class Datos {
    String name;
    String carrera;
    String noctrl;
    String photoId;

    public Datos(String name, String carrera,String noctrl, String photoId) {
        this.name = name;
        this.carrera = carrera;
        this.noctrl = noctrl;
        this.photoId = photoId;
    }

}